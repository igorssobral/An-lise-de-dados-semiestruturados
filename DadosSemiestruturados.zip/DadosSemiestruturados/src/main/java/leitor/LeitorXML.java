package leitor;

import java.io.FileReader;
import java.util.List;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import model.RegistroDeAlunos;

public class LeitorXML {
	
	private static List<RegistroDeAlunos> registros;
	
	public LeitorXML() {
		lerXML();
	}
	
	@SuppressWarnings("unchecked")
	private static void lerXML() {
		FileReader reader = null;
		
		try {
			reader = new FileReader("Relacao_de_Alunos_ufvjm.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		XStream xstream = new XStream(new DomDriver());
		registros = (List<RegistroDeAlunos>) xstream.fromXML(reader);
	}
	
	public void listarTodos() {
		for(RegistroDeAlunos alunos : registros) {
			System.out.println(alunos.toString());
			System.out.println();
		}
	}
	
	public void listarPorEstado(String estado) {
		for(RegistroDeAlunos alunos : registros) {
			if(alunos.getEstadoOrigem().equals(estado.toUpperCase())) {
				System.out.println(alunos.toString());
				System.out.println();
			}
		}
	}
	
	public void listarPorAnoDeIngresso(String anoDeIngresso) {
		for (RegistroDeAlunos alunos : registros) {
			if(alunos.getAnoIngresso().equals(anoDeIngresso)) {
				System.out.println(alunos.toString());
				System.out.println();
			}
		}
	}
}
