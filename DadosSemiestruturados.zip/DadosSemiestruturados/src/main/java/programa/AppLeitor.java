package programa;

import java.util.Scanner;
import leitor.LeitorXML;

public class AppLeitor {
	public static void main(String[] args) {
		
		LeitorXML leitor = new LeitorXML();
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			System.out.println("\n1 - Listar todos \n2 - Listar por estado \n3 - Listar por ano de ingresso");
			String opcao = scanner.nextLine();
			
			if(opcao.equals("1")) {
				leitor.listarTodos();
			}else if(opcao.equals("2")) {
				System.out.println("Insira a UF do estado: ");
				String UF = scanner.nextLine();
				leitor.listarPorEstado(UF);
			}else if(opcao.equals("3")) {
				System.out.println("Insira o ano de ingresso: ");
				String ano = scanner.nextLine();
				leitor.listarPorAnoDeIngresso(ano);
			}else if(opcao.equals("s")) {
				break;
			}
		}
		scanner.close();
	}
}
