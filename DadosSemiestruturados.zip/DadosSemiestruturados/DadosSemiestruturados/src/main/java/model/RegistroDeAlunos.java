package model;

public class RegistroDeAlunos {
	
	private String nomeDiscente;
	private String municipioOrigem;
	private String curso;
	private String campus;
	private long matricula;
	private String cpf;
	private String anoIngresso;
	private String estadoOrigem;
	
	public RegistroDeAlunos(String nomeDiscente,String municipioOrigem,String estadoOrigem,String curso,String campus,long matricula,String cpf,String anoIngresso) {
		this.nomeDiscente = nomeDiscente;
		this.municipioOrigem = municipioOrigem;
		this.curso = curso;
		this.campus = campus;
		this.matricula = matricula;
		this.cpf = cpf;
		this.anoIngresso = anoIngresso;
		this.estadoOrigem = estadoOrigem;
	}
	
	public String getNomeDiscente() {
		return nomeDiscente;
	}
	public void setNomeDiscente(String nomeDiscente) {
		this.nomeDiscente = nomeDiscente;
	}
	public String getMunicipioOrigem() {
		return municipioOrigem;
	}
	public void setMunicipioOrigem(String municipioOrigem) {
		this.municipioOrigem = municipioOrigem;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public String getCampus() {
		return campus;
	}
	public void setCampus(String campus) {
		this.campus = campus;
	}
	public long getMatricula() {
		return matricula;
	}
	public void setMatricula(long matricula) {
		this.matricula = matricula;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getAnoIngresso() {
		return anoIngresso;
	}
	public void setAnoIngresso(String dataIngresso) {
		this.anoIngresso = dataIngresso;
	}
	public String getEstadoOrigem() {
		return estadoOrigem;
	}
	public void setEstadoOrigem(String estadoOrigem) {
		this.estadoOrigem = estadoOrigem;
	}

	@Override
	public String toString() {
		return "RegistroDeAlunos [nomeDiscente=" + nomeDiscente + ", municipioOrigem=" + municipioOrigem + ", curso="
				+ curso + ", campus=" + campus + ", matricula=" + matricula + ", cpf=" + cpf + ", anoIngresso="
				+ anoIngresso + ", estadoOrigem=" + estadoOrigem + "]";
	}
	
}
